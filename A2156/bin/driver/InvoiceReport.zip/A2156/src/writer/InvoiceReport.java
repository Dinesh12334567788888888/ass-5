package writer;

public class InvoiceReport {

}
