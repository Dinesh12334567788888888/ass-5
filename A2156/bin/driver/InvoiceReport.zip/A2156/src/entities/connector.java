package entities;

public class connector {

}
